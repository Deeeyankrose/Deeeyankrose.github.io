$(document).ready(function(){
    $("button").click(function(){
     alert($("#abb").attr("href"));
    });
   });